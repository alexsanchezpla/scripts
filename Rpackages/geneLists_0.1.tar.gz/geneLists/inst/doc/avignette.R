## ----loadData------------------------------------------------------------
fileName<- system.file("extdata", "topTables.Rda", package = "geneLists")
load(fileName)
class(AvsB)
colnames(AvsB)
head(AvsB[,1:7])

## ------------------------------------------------------------------------
require(geneLists)
cbind(numGenesChanged(AvsB, "AvsB"), numGenesChanged(AvsL, "AvsL"), numGenesChanged(BvsL, "BvsL")) 

## ----filter1-------------------------------------------------------------
entrezs_01_up  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.01, updown="up", id2Select = "ENTREZ", FCcutoff=1, cols2Select =0) 
length(entrezs_01_up)

## ----filter2-------------------------------------------------------------
table_01_up  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.01, updown="up", id2Select = NULL, FCcutoff=1, cols2Select =1:3) 
dim(table_01_up)

