## ----loadData------------------------------------------------------------
fileName<- system.file("extdata", "topTables.Rda", package = "geneLists")
load(fileName)
class(AvsB)
colnames(AvsB)
head(AvsB[,1:7])

## ------------------------------------------------------------------------
require(geneLists)
cbind(numGenesChanged(AvsB, "AvsB"), numGenesChanged(AvsL, "AvsL"), numGenesChanged(BvsL, "BvsL")) 

## ----filter1-------------------------------------------------------------
entrezs_01_up  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.01, updown="up", id2Select = "ENTREZ", FCcutoff=1, cols2Select =0) 
length(entrezs_01_up)

## ----filter2-------------------------------------------------------------
table_01_up  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.01, updown="up", id2Select = NULL, FCcutoff=1, cols2Select =1:3) 
dim(table_01_up)

## ----prefilter-----------------------------------------------------------
AvsB0  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 1)
AvsL0  <- genesFromTopTable (AvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 1)
BvsL0  <- genesFromTopTable (BvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 1)

## ----filterByAdjPval-----------------------------------------------------
AvsB1  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05)
AvsL1  <- genesFromTopTable (AvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05)
BvsL1  <- genesFromTopTable (BvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05)

cat("AvsB: ", length(AvsB0), "-->", length(AvsB1), "\n")
cat("AvsL: ", length(AvsL0), "-->", length(AvsL1), "\n")
cat("BvsL: ", length(BvsL0), "-->", length(BvsL1), "\n")

## ----filterByUpDown------------------------------------------------------
AvsB1Up  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05, updown="up")
AvsL1Up  <- genesFromTopTable (AvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05, updown="up")
BvsL1Up  <- genesFromTopTable (BvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05, updown="up")

cat("AvsB: ", length(AvsB1), "-->", length(AvsB1Up), "\n")
cat("AvsL: ", length(AvsL1), "-->", length(AvsL1Up), "\n")
cat("BvsL: ", length(BvsL1), "-->", length(BvsL1Up), "\n")

AvsB1Down  <- genesFromTopTable (AvsB, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05, updown="down")
AvsL1Down  <- genesFromTopTable (AvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05, updown="down")
BvsL1Down  <- genesFromTopTable (BvsL, entrezOnly = TRUE, uniqueIds=TRUE, adjOrrawP = "adj", Pcutoff = 0.05, updown="down")

cat("AvsB: ", length(AvsB1), "-->", length(AvsB1Down), "\n")
cat("AvsL: ", length(AvsL1), "-->", length(AvsL1Down), "\n")
cat("BvsL: ", length(BvsL1), "-->", length(BvsL1Down), "\n")

## ----commonGenes---------------------------------------------------------
commonAvsLandBvsL <- intersect(AvsL0, BvsL0)
length(commonAvsLandBvsL)

